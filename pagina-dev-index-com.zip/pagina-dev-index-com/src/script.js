// Configuración del reproductor de YouTube
const playerOptions = {
    autoplay: 1,
    controls: 0,
    disablekb: 1,
    enablejsapi: 1,
    iv_load_policy: 3,
    loop: 1,
    modestbranding: 1,
    mute: 1,
    rel: 0,
    showinfo: 0,
    playsinline: 1
};

// ID del video de YouTube
// (Coloque aquí el ID de su video de YouTube)
const videoID = "oGd7ypbwc5U";

/**
 * Carga la API de YouTube de forma asíncrona.
 */
function loadYouTubeAPI() {
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    const firstScriptTag = document.getElementsByTagName("script")[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
}

// Variable para almacenar el reproductor de YouTube
let player;

/**
 * Inicializa el reproductor de YouTube.
 */
function onYouTubeIframeAPIReady() {
    player = new YT.Player("yt-player", {
        videoId: videoID,
        playerVars: { ...playerOptions, playlist: videoID },
        events: {
            onReady: onPlayerReady,
            onStateChange: onPlayerStateChange
        }
    });
}

/**
 * Maneja el evento 'ready' del reproductor.
 * @param {Object} event - El evento proporcionado por la API de YouTube.
 */
function onPlayerReady(event) {
    event.target.playVideo();
    resizeVideo();
    window.addEventListener('resize', resizeVideo);
}

/**
 * Ajusta el tamaño del video para cubrir toda la pantalla.
 */
function resizeVideo() {
    const videoRatio = 16 / 9;
    const windowRatio = window.innerWidth / window.innerHeight;
    const videoElement = document.getElementById('yt-player');
    
    if (windowRatio > videoRatio) {
        videoElement.style.width = '100vw';
        videoElement.style.height = 'calc(100vw * 9 / 16)';
    } else {
        videoElement.style.width = 'calc(100vh * 16 / 9)';
        videoElement.style.height = '100vh';
    }
}

/**
 * Maneja los cambios de estado del reproductor.
 * @param {Object} event - El evento proporcionado por la API de YouTube.
 */
function onPlayerStateChange(event) {
    if (event.data === YT.PlayerState.ENDED) {
        player.playVideo();
    }
}

/**
 * Asegura el tamaño de fuente correcto para el título del encabezado.
 */
function ensureCorrectFontSize() {
    const headerTitle = document.querySelector('header h1');
    if (headerTitle) {
        headerTitle.style.fontSize = '1.5rem';
    }
}

// Iniciar la carga de la API de YouTube
loadYouTubeAPI();

// Exponer la función de inicialización para que YouTube pueda llamarla
window.onYouTubeIframeAPIReady = onYouTubeIframeAPIReady;

// Ejecutar la función de ajuste de fuente cuando la página se carga
window.addEventListener('load', ensureCorrectFontSize);

// Ejecutar la función de ajuste de fuente cuando se navega de vuelta a la página
window.addEventListener('pageshow', function(event) {
    if (event.persisted) {
        ensureCorrectFontSize();
    }
});